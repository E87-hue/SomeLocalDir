# ![opengl](logo/opengl.png)

OpenGL is a cross-language, cross-platform application programming interface for rendering 2D and 3D vector graphics.

This version of OpenGL is powered by **freeglut**, a free-software/open-source alternative to the OpenGL Utility Toolkit (GLUT) library.

____________________________________________________________
*Learn more about OpenGL at https://www.opengl.org/.*

*Copyright ©1997-2023 The Khronos® Group Inc.*
  
    
    

